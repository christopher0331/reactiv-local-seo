# The Contractor's Local SEO Starter Pack

A done-for-you starter kit that helps home-service contractors (roofers, painters, landscapers, fence builders, plumbers, HVAC) show up in the Google Map Pack and win more local jobs.

Built by **Reactiv Labs** from playbooks we've run across 40+ contractor sites.

## What's inside

| File | What it does |
| --- | --- |
| `gbp-checklist.md` | 25-point Google Business Profile optimization checklist — the #1 ranking factor for local map visibility |
| `onpage-checklist.md` | On-page SEO checklist for service + city pages |
| `local-keywords.csv` | Editable local keyword tracker (service + city + volume + difficulty) |
| `citations.csv` | 50 high-authority citation sources to list your business on |
| `review-templates.md` | Copy-paste SMS + email templates to get more 5-star reviews |
| `30-day-plan.md` | A day-by-day 30-day local SEO action plan |

## How to use it

1. Work the GBP checklist first — it has the biggest, fastest impact.
2. Fill in the keyword tracker for your top 10 services × your top 5 cities.
3. Build out one optimized city page per week using the on-page checklist.
4. Submit citations from the list (start with the top 15).
5. Turn on the review templates and ask every happy customer.

That's it. Follow the 30-day plan and you'll be ahead of 90% of your local competition.

Questions? This is a pay-what-you-want pack — if it helped, tell a fellow contractor.
