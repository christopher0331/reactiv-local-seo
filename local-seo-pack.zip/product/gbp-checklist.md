# Google Business Profile (GBP) — 25-Point Optimization Checklist

Your GBP is the single biggest lever for showing up in the local Map Pack. Work top to bottom.

## Setup & Verification
- [ ] Profile is **claimed and verified** (postcard / video verification).
- [ ] Business name matches your real-world name (no keyword stuffing like "Joe's Roofing Best Roofers Seattle").
- [ ] Primary category is the most specific match (e.g. "Roofing contractor", not "Contractor").
- [ ] All relevant **secondary categories** added (e.g. "Gutter cleaning service").

## NAP & Contact
- [ ] Name, Address, Phone (NAP) is **identical** to your website footer and citation listings.
- [ ] Toll-free / tracking numbers are NOT used as the primary number.
- [ ] Website field points to your root domain (or a location page), not a third-party booking site.
- [ ] Primary and secondary phone numbers entered.

## Profile Content
- [ ] Business description written in first person, includes services + service areas + differentiators.
- [ ] Hours of operation complete for every day, including holidays where relevant.
- [ ] At least **5 high-quality photos** uploaded: logo, cover, storefront/jobsite, team, work-in-progress.
- [ ] Add a 30–60s intro video.
- [ ] Products / Services added with descriptions and prices where applicable.

## Engagement & Trust
- [ ] Enable and respond to **Google Reviews** within 24 hours (positive and negative).
- [ ] Turn on messaging / set an auto-reply.
- [ ] Post a Google Update / Offer at least every 2 weeks.
- [ ] Add Q&A entries you write yourself (common customer questions + answers).
- [ ] List **service areas** by city/neighborhood, not just a radius.
- [ ] Add attributes (Women-led, Veteran-owned, "Free estimates", "Online estimates").

## Advanced
- [ ] Booking link connected if you take appointments.
- [ ] "Products" section populated for your top 3 services.
- [ ] Use the Spam Report tool on fake competitor listings in your category.
- [ ] Audit and remove duplicate GBP listings.
- [ ] Track ranking of your primary keyword weekly (BrightLocal / Semrush Map Rank tracker).

> Rule of thumb: a complete, active, review-rich GBP outranks a thin one 9 times out of 10 — even with a weaker website.
