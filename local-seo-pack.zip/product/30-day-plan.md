# 30-Day Local SEO Action Plan

Follow in order. ~30–60 minutes/day.

## Week 1 — Foundation
- **Day 1–2:** Claim + verify GBP; complete the 25-point GBP checklist.
- **Day 3:** Fix NAP consistency across website footer + top 5 citations.
- **Day 4:** Upload 10 photos + 1 video to GBP.
- **Day 5:** Write your business description (first person, services + areas).
- **Day 6–7:** Fill in the keyword tracker (10 services × 5 cities).

## Week 2 — Content
- **Day 8–12:** Build 1 optimized city/service page per day using the on-page checklist.
- **Day 13:** Add LocalBusiness schema to your site.
- **Day 14:** Embed a Google Map + write 3 FAQs per top page.

## Week 3 — Citations
- **Day 15–19:** Submit to top 15 citation sources from `citations.csv`.
- **Day 20–21:** Claim Yelp, Bing, Apple Business Connect; sync from GBP.

## Week 4 — Reviews & Authority
- **Day 22–26:** Launch review templates — text/email every recent customer.
- **Day 27:** Respond to all existing reviews (positive + negative).
- **Day 28–29:** Publish 2 Google Updates / posts.
- **Day 30:** Record baseline rankings; set a weekly 15-min ranking check.

## Ongoing (after day 30)
- Post a Google Update every 2 weeks.
- Ask for a review after every completed job.
- Add one new city page per month until you cover your full service area.
- Watch the Map Pack ranking of your top 3 keywords weekly.

> Most contractors see Map Pack movement in 4–8 weeks if they stay consistent.
