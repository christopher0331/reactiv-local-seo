# Review-Request Templates

Reviews are the #2 local ranking factor and the #1 trust signal. Ask every happy customer.

## SMS (send 1–3 days after job completion)

> Hi {FirstName}, thanks again for choosing {Company}! If you've got 30 seconds, a Google review really helps us out: {ReviewLink} — {YourName}

## Email (same day as invoice)

> Subject: Quick favor?
>
> Hi {FirstName},
>
> It was great working on {JobSummary} for you. If you're happy with how it turned out, would you mind leaving us a quick Google review? It takes under a minute and helps homeowners like you find a contractor they can trust.
>
> {ReviewLink}
>
> Thanks so much,
> {YourName} — {Company}

## Post-card (leave on completed jobsite)

> Loved the work? Tell Google.
> Scan here to leave a 5-star review: {ReviewLink}
> {Company} · {Phone}

## How to 3x your review rate
1. Ask at the **peak moment of delight** (job done, invoice paid, problem solved).
2. Make it **one tap** — always include the direct GBP review link.
3. Respond to **every** review within 24 hours — it signals an active business.
4. Never offer incentives for positive reviews (violates Google's policy) — just ask.

## Responding to a negative review (template)

> Hi {Name}, I'm sorry this didn't meet your expectations. We'd like to make it right — please call me directly at {Phone}. — {OwnerName}, {Company}
