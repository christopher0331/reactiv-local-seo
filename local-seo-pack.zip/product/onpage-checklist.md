# On-Page SEO Checklist (Service & City Pages)

Use this for every service page and every location page you build.

## Page Structure
- [ ] One primary keyword per page (e.g. "fence installation Seattle").
- [ ] Title tag: Primary keyword + City + Brand (≤ 60 chars).
- [ ] Meta description includes keyword + value prop + CTA (≤ 155 chars).
- [ ] H1 contains the primary keyword exactly once.
- [ ] URL is clean: `/services/fence-installation-seattle`.

## Content
- [ ] 400+ words of unique, helpful copy (not duplicated across cities).
- [ ] At least one H2 with a secondary keyword.
- [ ] Real photos with descriptive `alt` text (filename + alt include the keyword).
- [ ] Internal links to related services and 2–3 city pages.
- [ ] A clear CTA + click-to-call phone button above the fold.
- [ ] Customer reviews / testimonials embedded on the page.
- [ ] FAQ section targeting "people also ask" questions.

## Technical
- [ ] Page loads under 2s (mobile).
- [ ] Mobile-friendly (no horizontal scroll, tap targets ≥ 44px).
- [ ] Schema.org `LocalBusiness` / `Service` markup present.
- [ ] Canonical tag set correctly.
- [ ] Image compression applied (WebP).
- [ ] HTTPS enabled sitewide.

## Local Signals
- [ ] NAP in site footer matches GBP exactly.
- [ ] Embedded Google Map of the service area.
- [ ] Landmark / neighborhood references in the copy ("near Green Lake", "serving Ballard & Fremont").
- [ ] Local link (chamber of commerce, local sponsor, supplier) where possible.
